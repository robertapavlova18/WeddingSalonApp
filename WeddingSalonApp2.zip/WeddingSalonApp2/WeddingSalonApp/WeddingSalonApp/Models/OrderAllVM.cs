﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WeddingSalonApp.Entities;

namespace WeddingSalonApp.Models
{
    public class OrderAllVM
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string OrderedOn { get; set; }
        [Display(Name = "Product")]
        public int ProductId { get; set; }

       public virtual Product Product { get; set; }
        public string Model { get; set; }
        public string Picture { get; set; }
   

        public string UserId { get; set; }
        [Display(Name = "User")]
        public string User { get; set; }
        public int Quantity { get; set; }
        
        public decimal Price { get; set; }
        

        public decimal TotalPrice { get; set; }
    }
}
