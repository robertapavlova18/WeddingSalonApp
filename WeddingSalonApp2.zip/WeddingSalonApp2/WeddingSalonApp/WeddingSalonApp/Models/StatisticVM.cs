﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WeddingSalonApp.Models
{
    public class StatisticVM
    {
        public int countProducts { get; set; }
        public int countUsers { get; set; }
        public int countOrders { get; set; }
    }
}
