﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using WeddingSalonApp.Models.Brands;
using WeddingSalonApp.Models.Category;

namespace WeddingSalonApp.Entities
{
    public class Product
    {
        public Product()
        {
            Categories = new List<CategoryChoiceVM>();
            Brands= new List<BrandChoiceVM>();
        }
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Display(Name = "Code")]
        public string ProductCode { get; set; }

        public string Model { get; set; }
        public int CategoryId { get; set; }
        public virtual Category Category { get; set; }
        public virtual List<CategoryChoiceVM> Categories { get; set; }
        public int BrandId { get; set; }
        public virtual Brand Brand { get; set; }
        public virtual List<BrandChoiceVM> Brands { get; set; }
        [Display(Name = "Info")]
        public string Description { get; set; }
        [Display(Name = "Collection")]
        public string ProductCollection { get; set; }

        public string Picture { get; set; }
      //  public virtual Image Image { get; set; }
        public decimal Price { get; set; }

        public int Quantity { get; set; }

        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

   

    }
}
