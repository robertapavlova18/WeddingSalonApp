﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using WeddingSalonApp.Data;
using WeddingSalonApp.Entities;
using WeddingSalonApp.Models;

namespace WeddingSalonApp.Controllers
{
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext context;

        public OrderController(ApplicationDbContext context)
        {
            this.context = context;
        }
        [HttpPost]

        public IActionResult Create(OrderCreateVM bindingModel)
        {
            if (this.ModelState.IsValid)
            {
                string userId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
                var user = this.context.Users.SingleOrDefault(u => u.Id == userId);
                var ev = this.context.Products.SingleOrDefault(e => e.Id == bindingModel.ProductId);

                if (user == null || ev == null || ev.Quantity < bindingModel.Quantity)
                {

                    return this.RedirectToAction("Index", "Products");
                }
                Order orderForDb = new Order
                {
                    OrderedOn = DateTime.UtcNow,
                    ProductId = ev.Id,
                    UserId = userId,
                    Quantity = bindingModel.Quantity,
                    Picture=ev.Picture,
                    Model=ev.Model,

                    Price = ev.Price,


                };






                ev.Quantity -= bindingModel.Quantity;
                this.context.Products.Update(ev);
                this.context.Orders.Add(orderForDb);
                this.context.SaveChanges();
            }
            return this.RedirectToAction("Index", "Products");
        }
        [Authorize(Roles = "Administrator")]
        public IActionResult Index()
        {
            string userId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = context.Users.SingleOrDefault(u => u.Id == userId);

           
            List<OrderAllVM> orders = context
                 .Orders
                 .Select(x => new OrderAllVM
                 {
                     Id = x.Id,
                     ProductId=x.ProductId,


                     OrderedOn = x.OrderedOn.ToString("dd-mm-yyyy hh:mm", CultureInfo.InvariantCulture),
                     Model = x.Model,
                     Picture = x.Picture,
                     Price = x.Price,
                     Quantity = x.Quantity,
                     User=x.User.UserName,
                   

                     TotalPrice = x.TotalPrice,

                 }).ToList();



            return View(orders);
        }
        [Authorize]
        public IActionResult My(string searchString)
        {
            string currentUserId = this.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = this.context.Users.SingleOrDefault(u => u.Id == currentUserId);
            if (user == null)
            {
                return null;
            }

            List<OrderAllVM> orders = context
                 .Orders
                 .Select(x => new OrderAllVM
                 {
                     Id = x.Id,
                     ProductId = x.ProductId,


                     OrderedOn = x.OrderedOn.ToString("dd-mm-yyyy hh:mm", CultureInfo.InvariantCulture),
                     Model = x.Model,
                     Picture = x.Picture,
                     Price = x.Price,
                     Quantity = x.Quantity,
                     User = x.User.UserName,


                     TotalPrice = x.TotalPrice,

                 }).ToList();




            return this.View(orders);
        }

    }
}
